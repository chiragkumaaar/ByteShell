#include <iostream>
#include <string>
using namespace std;

void print_prompt1()
{
    cerr << "$ ";
}

void print_prompt2()
{
    cerr << "> ";
}